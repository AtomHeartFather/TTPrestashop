SET NAMES 'utf8';

ALTER TABLE `PREFIX_feature_product` ADD INDEX `id_product`(`id_product`);
